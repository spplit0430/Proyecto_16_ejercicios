package com.example.proyectokotlinfundamentos

// Nombre: DAVID FRANCISCO GARCIA AMADOR
// Fecha: 06/02/2025
// Descripción: Solución del Problema 3 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema3()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema3() {
    // Pedimos la asignatura y las calificaciones de los tres cortes académicos
    println("Ingresa la asignatura:")
    val asignatura = readLine()!!

    println("Ingresa nota primer corte:")
    val corte1 = readLine()!!.toDouble()

    println("Ingresa nota segundo corte:")
    val corte2 = readLine()!!.toDouble()

    println("Ingresa nota tercer corte:")
    val corte3 = readLine()!!.toDouble()

    // Calculamos la calificación final con los pesos respectivos
    val calificacionFinal = corte1 * 0.33 + corte2 * 0.33 + corte3 * 0.34

    // Imprimimos la asignatura y la calificación final siguiendo el formato requerido
    println("Asignatura: $asignatura")
    println("Definitiva: $calificacionFinal")
}


