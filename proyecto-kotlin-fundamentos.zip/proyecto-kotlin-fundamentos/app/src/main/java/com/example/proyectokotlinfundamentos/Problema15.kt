package com.example.proyectokotlinfundamentos

// Nombre: DAVID FRANCISCO GARCIA AMADOR
// Fecha: 06/02/2025
// Descripción: Solución del Problema 15 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema15()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema15() {
    // Solicitar al usuario que ingrese un número de 4 cifras
    println("Dame un numero de 4 cifras:")
    // Leer el número
    val num = readLine()!!.toInt()
    // Convertir el número a una cadena de texto
    val numStr = num.toString()
    // Verificar si el número es un palíndromo (si se lee igual al revés)
    if (numStr == numStr.reversed()) {
        println("SÍ")
    } else {
        println("NO")
    }
}

