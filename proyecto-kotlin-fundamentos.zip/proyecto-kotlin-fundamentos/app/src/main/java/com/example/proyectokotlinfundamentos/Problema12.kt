package com.example.proyectokotlinfundamentos

// Nombre: DAVID FRANCISCO GARCIA AMADOR
// Fecha: 06/02/2025
// Descripción: Solución del Problema 12 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema12()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema12() {
    println("Dame num1:")
    val num1 = readLine()!!.toInt()

    println("Dame num2:")
    val num2 = readLine()!!.toInt()

    println("Dame num3:")
    val num3 = readLine()!!.toInt()

    val igual = when {
        num1 == num2 && num2 == num3 -> 3
        num1 == num2 || num1 == num3 || num2 == num3 -> 2
        else -> 0
    }

    println(igual)
}

