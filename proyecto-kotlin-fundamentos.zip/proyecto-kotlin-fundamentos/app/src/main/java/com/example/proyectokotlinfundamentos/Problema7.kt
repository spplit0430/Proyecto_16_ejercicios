package com.example.proyectokotlinfundamentos

// Nombre: DAVID FRANCISCO GARCIA AMADOR
// Fecha: 06/02/2025
// Descripción: Solución del Problema 7 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema7()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema7() {
    println("¿Cuántos sonidos del grillo escuchaste por minuto?")
    val n = readLine()!!.toInt()

    if (n < 0) {
        println("Seguro investigador, ¿un grillo puede hacer ese número de sonidos?")
    } else {
        val temperatura = (n / 4.0) + 40.0
        println("Dados los sonidos del grillo, la temperatura es de $temperatura °F.")
    }
}
