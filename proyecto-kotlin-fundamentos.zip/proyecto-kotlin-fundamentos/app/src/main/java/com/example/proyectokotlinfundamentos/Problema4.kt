package com.example.proyectokotlinfundamentos

// Nombre: DAVID FRANCISCO GARCIA AMADOR
// Fecha: 06/02/2025
// Descripción: Solución del Problema 4 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema4()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema4() {
    val impuesto = 0.18

    // Solicitar el precio de los tres artículos
    println("Ingresa valor artículo 1:")
    val articulo1 = readLine()!!.toDouble()

    println("Ingresa valor artículo 2:")
    val articulo2 = readLine()!!.toDouble()

    println("Ingresa valor artículo 3:")
    val articulo3 = readLine()!!.toDouble()

    // Calcular el valor total neto (sin impuestos)
    val totalNeto = articulo1 + articulo2 + articulo3

    // Calcular el total con impuesto
    val totalConImpuesto = totalNeto * (1 + impuesto)

    // Mostrar los resultados
    println("Valor neto: $totalNeto")
    println("Valor total: $totalConImpuesto")
}
