package com.example.proyectokotlinfundamentos

// Nombre: DAVID FRANCISCO GARCIA AMADOR
// Fecha: 06/02/2025
// Descripción: Solución del Problema 9 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema9()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema9() {
    // Leemos los números del usuario
    println("Dame num1:")  // Asegúrate de que el mensaje sea exactamente como el test lo espera
    val num1 = readLine()!!.toInt()  // Leemos el primer número

    println("Dame num2:")  // Asegúrate de que el mensaje sea exactamente como el test lo espera
    val num2 = readLine()!!.toInt()  // Leemos el segundo número

    // Verificamos si num1 es mayor que el doble de num2
    if (num1 > 2 * num2) {
        println("Wow!")  // Si num1 es mayor que el doble de num2
    } else {
        println("Aburrido!")  // En caso contrario
    }
}
