package com.example.proyectokotlinfundamentos

// Nombre: DAVID FRANCISCO GARCIA AMADOR
// Fecha: 06/02/2025
// Descripción: Solución del Problema 10 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema10()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema10() {
    // Pedimos al usuario que ingrese un número
    println("Dame num:")
    val num = readLine()!!.toInt()  // Leemos el número ingresado

    // Verificamos si el número es divisible por 10
    if (num % 10 == 0) {
        println("Divisible.")  // Si es divisible por 10
    } else {
        println("No divisible.")  // Si no es divisible por 10
    }
}
