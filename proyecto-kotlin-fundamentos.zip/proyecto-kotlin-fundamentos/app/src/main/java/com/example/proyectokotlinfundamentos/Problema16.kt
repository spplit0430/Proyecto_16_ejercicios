package com.example.proyectokotlinfundamentos

// Nombre: DAVID FRANCISCO GARCIA AMADOR
// Fecha: 06/02/2025
// Descripción: Solución del Problema 16 de la guía de Kotlin fundamentos

// Función principal
fun main() {
     problema16()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema16() {
    // Solicitar la entrada del usuario
    println("n:")
    val n = readLine()!!.toInt()
    println("m:")
    val m = readLine()!!.toInt()
    println("k:")
    val k = readLine()!!.toInt()

    // Verificar si se puede dividir la barra de chocolate en k cuadrados
    if ((k % n == 0 && k / n <= m) || (k % m == 0 && k / m <= n)) {
        println("SÍ")
    } else {
        println("NO")
    }
}