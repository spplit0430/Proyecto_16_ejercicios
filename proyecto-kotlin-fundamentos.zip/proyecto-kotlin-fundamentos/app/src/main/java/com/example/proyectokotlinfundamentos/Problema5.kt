package com.example.proyectokotlinfundamentos

// Nombre: DAVID FRANCISCO GARCIA AMADOR
// Fecha: 06/02/2025
// Descripción: Solución del Problema 5 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema5()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema5() {
    // Mensajes de entrada según el test
    println("e:")
    val e = readLine()!!.toInt()

    println("m:")
    val m = readLine()!!.toInt()

    // Cálculos de distribución de manzanas
    val manzanasPorEstudiante = if (e > 0) m / e else 0
    val manzanasRestantes = if (e > 0) m % e else m

    // Mensajes de salida exactos
    println("Cada estudiante recibirá: $manzanasPorEstudiante manzanas.")
    println("Quedarán en la canasta: $manzanasRestantes manzanas.")
}
