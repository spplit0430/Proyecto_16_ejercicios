package com.example.proyectokotlinfundamentos

// Nombre: DAVID FRANCISCO GARCIA AMADOR
// Fecha: 06/02/2025
// Descripción: Solución del Problema 14 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema14()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema14() {
    println("Dame num1:")
    val num1 = readLine()!!.toInt()

    println("Dame num2:")
    val num2 = readLine()!!.toInt()

    println("Dame num3:")
    val num3 = readLine()!!.toInt()

    val mayor = maxOf(num1, num2, num3)

    // Contamos cuántas veces aparece el número mayor
    val count = listOf(num1, num2, num3).count { it == mayor }

    // Si el número mayor aparece más de una vez, hay un empate
    if (count > 1) {
        println("Hay un empate!")
    } else {
        println(mayor)
    }
}

