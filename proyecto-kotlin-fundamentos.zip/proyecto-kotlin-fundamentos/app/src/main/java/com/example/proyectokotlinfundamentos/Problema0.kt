package com.example.proyectokotlinfundamentos

// Nombre: DAVID FRANCISCO GARCIA AMADOR
// Fecha: 06/02/2025
// Descripción: Solución del Problema 0 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema0()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema0() {
    // Desarrolle aquí la lógica
    val codigoascii = """
                              __..----..__
        `.`.| |:          _,-':::''' '  `:`-._
          `.:\||       _,':::::'         `::::`-.
            \\`|    _,':::::::'     `:.     `':::`.
             ;` `-''  `::::::.                  `::\
          ,-'      .::'  `:::::.         `::..    `:\
        ,' /_) -.            `::.           `:.     |
      ,'.:     `    `:.        `:.     .::.          \
 __,-'   ___,..-''-.  `:.        `.   /::::.         |
|):'_,--'           `.    `::..       |::::::.      ::\
 `-'                 |`--.:_::::|_____\::::::::.__  ::|
                     |   _/|::::|      \::::::|::/\  :|
                     /:./  |:::/        \__:::):/  \  :\
                   ,'::'  /:::|        ,'::::/_/    `. ``-.__
                  ''''                ,';':,-'         `-.__  `'--..__                                             
        """.trimIndent()
    println(codigoascii)
}