package com.example.proyectokotlinfundamentos

// Nombre: DAVID FRANCISCO GARCIA AMADOR
// Fecha: 06/02/2025
// Descripción: Solución del Problema 13 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema13()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema13() {
    println("Dame un numero:")
    val num = readLine()!!.toInt()

    val centena = num / 100
    val decena = (num / 10) % 10
    val unidad = num % 10

    if (centena < decena && decena < unidad) {
        println("SÍ")
    } else {
        println("NO")
    }
}
