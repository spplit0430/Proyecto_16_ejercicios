package com.example.proyectokotlinfundamentos

// Nombre: DAVID FRANCISCO GARCIA AMADOR
// Fecha: 06/02/2025
// Descripción: Solución del Problema 8 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema8()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema8() {
    // Pedimos la base y el exponente al usuario
    println("Dame la base:")
    val base = readLine()!!.toInt() // Leemos la base como un entero

    println("Dame el exponente:")
    val exponente = readLine()!!.toInt() // Leemos el exponente como un entero

    // Calculamos la base elevada al exponente
    val resultado = Math.pow(base.toDouble(), exponente.toDouble())

    // Validamos si el resultado es mayor a 5000
    if (resultado > 5000) {
        println("Muy grande.")
    } else {
        println("Números óptimos.")
    }
}
