package com.example.proyectokotlinfundamentos

// Nombre: DAVID FRANCISCO GARCIA AMADOR
// Fecha: 06/02/2025
// Descripción: Solución del Problema 6 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema6()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema6() {
    println("Dame un número entero:")
    val numero = readLine()!!.toInt()

    val centena = numero / 100
    val decena = (numero / 10) % 10
    val unidad = numero % 10

    val suma = centena+decena+unidad

    println("La suma de los dígitos del número $numero es igual a $suma.")
}
