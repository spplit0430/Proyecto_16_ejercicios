package com.example.proyectokotlinfundamentos

// Nombre: DAVID FRANCISCO GARCIA AMADOR
// Fecha: 06/02/2025
// Descripción: Solución del Problema 2 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema2()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema2() {
    // Solicitar entrada del número entero a
    println("Ingresa a:")
    val a = readLine()!!.toInt() // Convertir directamente a entero

    // Solicitar entrada del número entero b
    println("Ingresa b:")
    val b = readLine()!!.toInt() // Convertir directamente a entero

    // Realizar la suma
    val suma = a + b

    // Imprimir el resultado
    println("$a + $b = $suma")
}